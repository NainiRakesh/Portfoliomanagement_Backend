//package com.sonata.portfoliomanagement.model;
//
//import jakarta.persistence.*;
//
//@Entity
//@Table(name="users")
//public class User {
//    @Id
//    @GeneratedValue(strategy = GenerationType.SEQUENCE)
//    private int id;
//
//    @Column(name="email",nullable = false,length = 100,unique = false)
//    private String email;
//
//    @Column (name="password",nullable = false,length = 100,unique = true)
//    private String password;
//
//    @Column(name="is_first_login",length = 100)
//    private boolean isFirstLogin;
//
//    // Getter and setter for isFirstLogin
//    public boolean isFirstLogin() {
//        return isFirstLogin;
//    }
//
//    public void setFirstLogin(boolean isFirstLogin) {
//        this.isFirstLogin = isFirstLogin;
//    }
//
//    public int getId() {
//        return id;
//    }
//
//    public void setId(int id) {
//        this.id = id;
//    }
//
//    public String getPassword() {
//        return password;
//    }
//
//    public void setPassword(String password) {
//        this.password = password;
//    }
//
//    public String getEmail() {
//        return email;
//    }
//
//    public void setEmail(String email) {
//        this.email = email;
//    }
//
//
//}
