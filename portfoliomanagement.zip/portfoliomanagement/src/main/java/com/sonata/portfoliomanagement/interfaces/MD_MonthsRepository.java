package com.sonata.portfoliomanagement.interfaces;

import com.sonata.portfoliomanagement.model.MD_Months;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MD_MonthsRepository extends JpaRepository<MD_Months, Integer> {

}
